const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'SUMMARIZE_POST') {
        handleSummarize(request.payload, sendResponse);
        return true; // Indicate that response will be sent asynchronously
    }
});

async function handleSummarize(payload, sendResponse) {
    try {
        const result = await chrome.storage.local.get(['geminiApiKey']);
        const apiKey = result.geminiApiKey;

        if (!apiKey) {
            sendResponse({ success: false, error: "API Key not found. Please set your Gemini API key in the extension settings." });
            return;
        }

        const prompt = "You are an AI assistant designed to help users mindfully consume social media. Read this text caption and view the provided image if any. Make an assumption about what this post is about. Output a JSON object containing two fields: 'summary' (a brief paragraph explaining the post. CRITICAL: Do NOT use raw line breaks/newlines inside the string) and 'keywords' (an array of 1-4 strings representing main topics). Response must be a single JSON object. Do not use markdown formatting. If the content contains double quotes, you MUST escape them with a backslash (e.g., \\\").";
        
        const contents = [
            {
                "role": "user",
                "parts": [
                    { "text": `${prompt}\n\nCaption/Title: ${payload.text}` }
                ]
            }
        ];

        // If there's an image, fetch it, convert to base64, and attach it
        if (payload.imageUrl && !payload.imageUrl.startsWith('data:')) {
            try {
                // Fetch the image as a blob
                const imgRes = await fetch(payload.imageUrl);
                const blob = await imgRes.blob();
                
                // Convert blob to base64 directly in background script
                const base64data = await blobToBase64(blob);
                
                // Determine mime type from blob or url
                const mimeType = blob.type || "image/jpeg";
                
                // Add to contents payload
                contents[0].parts.push({
                    "inline_data": {
                        "mime_type": mimeType,
                        "data": base64data.split(',')[1] // Get base64 without data URI prefix
                    }
                });
            } catch (e) {
                console.error("Failed to fetch image, continuing with text only:", e);
                // Continue with just text if image fetch fails due to CORS, etc.
            }
        } else if (payload.imageUrl && payload.imageUrl.startsWith('data:')) {
             const parts = payload.imageUrl.split(',');
             const mimeTypeMatches = parts[0].match(/:(.*?);/);
             const mimeType = mimeTypeMatches ? mimeTypeMatches[1] : 'image/jpeg';
             
             contents[0].parts.push({
                 "inline_data": {
                     "mime_type": mimeType,
                     "data": parts[1]
                 }
             });
        }

        const requestBody = {
            "contents": contents,
            "generationConfig": {
                "temperature": 0.3,
                "maxOutputTokens": 600,
                "responseMimeType": "application/json"
            }
        };

        const response = await fetch(`${GEMINI_API_URL}?key=${apiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });

        const data = await response.json();

        if (!response.ok) {
            console.error("Gemini API Error:", data);
            throw new Error(data.error?.message || `API error: ${response.status}`);
        }

        const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
        
        if (!rawText) {
            throw new Error("No summary generated from API");
        }

        let cleanedText = rawText.trim();
        // Sometimes the AI still outputs markdown formatting, which breaks JSON.parse
        if (cleanedText.startsWith('```')) {
            const match = cleanedText.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
            if (match && match[1]) {
                cleanedText = match[1].trim();
            }
        }
        
        // Strip out literal newlines safely using regex (common source of "Unterminated string")
        cleanedText = cleanedText.replace(/[\n\r]+/g, " ");

        const parsed = robustParse(cleanedText);

        sendResponse({ success: true, summary: parsed.summary, keywords: parsed.keywords });

    } catch (error) {
        console.error("Summarization failed:", error);
        sendResponse({ success: false, error: error.message });
    }
}

function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}

function robustParse(rawText) {
  // 1. Find the first '{' and last '}' to ignore any extra AI chatter or backticks
  const jsonStart = rawText.indexOf('{');
  const jsonEnd = rawText.lastIndexOf('}') + 1;
  let jsonString = rawText.slice(jsonStart, jsonEnd);

  // 2. Fix common LLM errors: newlines inside strings and unescaped quotes
  // This replaces actual newlines with the string "\n" so JSON doesn't break
  jsonString = jsonString.replace(/\n/g, "\\n").replace(/\r/g, "\\r");

  return JSON.parse(jsonString);
}
