// Constants
const IG_ARTICLE_SELECTOR = 'article:has(img)';
const YT_VIDEO_SELECTOR = 'ytd-rich-grid-media, ytd-compact-video-renderer';

// Helper to check what platform we are on
const isInstagram = window.location.hostname.includes('instagram.com');
const isYouTube = window.location.hostname.includes('youtube.com');

// Set to keep track of processed elements
const processedElements = new WeakSet();

// Initialize Mutation Observer to watch for DOM changes (infinite scroll)
const observer = new MutationObserver(handleMutations);
observer.observe(document.body, { childList: true, subtree: true });

// Process existing elements on load
window.addEventListener('load', processExistingElements);

function processExistingElements() {
    if (isInstagram) {
        document.querySelectorAll(IG_ARTICLE_SELECTOR).forEach(processElement);
    } else if (isYouTube) {
        document.querySelectorAll(YT_VIDEO_SELECTOR).forEach(processElement);
    }
}

function handleMutations(mutations) {
    if (isInstagram) {
        document.querySelectorAll(IG_ARTICLE_SELECTOR).forEach(processElement);
    } else if (isYouTube) {
        document.querySelectorAll(YT_VIDEO_SELECTOR).forEach(processElement);
    }
}

function processElement(element) {
    if (processedElements.has(element)) return;

    // Instagram specific logic: articles take a while to load their images fully.
    // It's sometimes safer to just put the overlay over the entire article immediately.
    let targetContainer = null;
    let textExtractor = null;
    let imageExtractor = null;

    if (isInstagram) {
        // Overlay the entire article to cover the post completely using the Shadow DOM wrapper
        targetContainer = element;
        
        textExtractor = () => {
            const img = element.querySelector('img');
            const altText = img ? img.alt : "";
            const textContent = element.innerText || "";
            return `Alt text: ${altText}\nContent: ${textContent.substring(0, 600)}`;
        };
        
        imageExtractor = () => {
            const img = element.querySelector('img');
            return img ? img.src : null;
        };
        
    } else if (isYouTube) {
        const thumbnailContainer = element.querySelector('ytd-thumbnail');
        if (!thumbnailContainer) return; // Wait for thumbnail
        
        targetContainer = thumbnailContainer;
        
        textExtractor = () => {
            const img = element.querySelector('img');
            const altText = img ? img.alt : "";
            const textContent = element.innerText || "";
            return `Alt text: ${altText}\nContent: ${textContent.substring(0, 600)}`;
        };
        
        imageExtractor = () => {
            const img = element.querySelector('img');
            return img ? img.src : null;
        };
    }

    if (targetContainer) {
        processedElements.add(element);
        injectOverlay(targetContainer, textExtractor, imageExtractor);
    }
}

function injectOverlay(container, textExtractor, imageExtractor) {
    // Prevent double injection
    if (container.querySelector('.mindful-overlay-wrapper')) return;
    
    // Ensure parent has position relative
    const computedStyle = window.getComputedStyle(container);
    if (computedStyle.position === 'static') {
        container.style.position = 'relative';
    }

    const wrapper = document.createElement('div');
    wrapper.className = 'mindful-overlay-wrapper';
    Object.assign(wrapper.style, {
        position: 'absolute',
        inset: '0',
        zIndex: '10000',
        background: '#000',
        transition: 'opacity 0.3s ease'
    });

    const shadowRoot = wrapper.attachShadow({ mode: 'open' });

    const styleLink = document.createElement('link');
    styleLink.rel = 'stylesheet';
    styleLink.href = chrome.runtime.getURL('content.css');
    shadowRoot.appendChild(styleLink);

    const overlay = document.createElement('div');
    overlay.className = 'mindful-overlay';

    const logo = document.createElement('div');
    logo.className = 'mindful-logo';

    const title = document.createElement('div');
    title.className = 'mindful-title';
    title.innerText = "Mindful Pause";

    const subtitle = document.createElement('div');
    subtitle.className = 'mindful-subtitle';
    subtitle.innerText = "Take a breath before consuming this content.";

    const contentWrapper = document.createElement('div');
    contentWrapper.style.display = 'flex';
    contentWrapper.style.flexDirection = 'column';
    contentWrapper.style.alignItems = 'center';

    const summarizeBtn = document.createElement('button');
    summarizeBtn.className = 'mindful-btn';
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '16');
    svg.setAttribute('height', '16');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '2');
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', 'M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6');
    svg.appendChild(path);
    summarizeBtn.appendChild(svg);
    summarizeBtn.appendChild(document.createTextNode(' Summarize'));
    
    const unhideBtn = document.createElement('button');
    unhideBtn.className = 'mindful-btn unhide';
    unhideBtn.innerText = "View anyway";

    contentWrapper.appendChild(summarizeBtn);
    contentWrapper.appendChild(unhideBtn);

    overlay.appendChild(logo);
    overlay.appendChild(title);
    overlay.appendChild(subtitle);
    overlay.appendChild(contentWrapper);

    // Event listeners
    unhideBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        wrapper.style.opacity = '0';
        wrapper.style.pointerEvents = 'none';
        setTimeout(() => wrapper.remove(), 300);
    });

    summarizeBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        // Prevent multiple clicks
        if (summarizeBtn.classList.contains('loading')) return;

        summarizeBtn.classList.add('loading');
        summarizeBtn.textContent = '';
        const spinner = document.createElement('span');
        spinner.className = 'mindful-spinner';
        summarizeBtn.appendChild(spinner);
        summarizeBtn.appendChild(document.createTextNode(' Analyzing...'));
        
        // Remove error if any
        const existingError = overlay.querySelector('.mindful-error');
        if (existingError) existingError.remove();

        const payload = {
            text: textExtractor(),
            imageUrl: imageExtractor()
        };

        try {
            chrome.runtime.sendMessage({
                action: 'SUMMARIZE_POST',
                payload: payload
            }, (response) => {
                if (chrome.runtime.lastError) {
                    showError("Error connecting to background script.", contentWrapper, summarizeBtn);
                    return;
                }

                if (response.success && response.summary) {
                    showSummaryAndUnhide(response.summary, response.keywords, contentWrapper, summarizeBtn, unhideBtn);
                } else {
                    showError(response.error || "Failed to generate summary.", contentWrapper, summarizeBtn);
                }
            });
        } catch (err) {
            showError("Unexpected error occurred.", contentWrapper, summarizeBtn);
        }
    });

    // Make sure we trap clicks from going below the overlay (playing videos etc)
    wrapper.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
    });

    shadowRoot.appendChild(overlay);
    container.appendChild(wrapper);
}

function showSummaryAndUnhide(summaryText, keywords, contentWrapper, originalBtn, unhideBtn) {
    // Hide original summarize button
    originalBtn.style.display = 'none';

    // Show summary text
    const summaryDiv = document.createElement('div');
    summaryDiv.className = 'mindful-summary';
    summaryDiv.innerText = summaryText;

    contentWrapper.insertBefore(summaryDiv, unhideBtn);

    // Create keyword boxes if present
    if (keywords && Array.isArray(keywords) && keywords.length > 0) {
        const keywordContainer = document.createElement('div');
        keywordContainer.className = 'mindful-keywords';
        keywords.forEach(kw => {
            const pill = document.createElement('span');
            pill.className = 'mindful-keyword-pill';
            pill.innerText = kw;
            keywordContainer.appendChild(pill);
        });
        contentWrapper.insertBefore(keywordContainer, unhideBtn);
    }

    // Change "View anyway" to "View content" for better UX flow
    unhideBtn.innerText = "View content";
}

function showError(errorText, contentWrapper, btn) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'mindful-error';
    errorDiv.innerText = errorText;
    
    contentWrapper.insertBefore(errorDiv, btn);
    
    // Reset button
    btn.classList.remove('loading');
    btn.textContent = '';
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '16');
    svg.setAttribute('height', '16');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '2');
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', 'M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6');
    svg.appendChild(path);
    btn.appendChild(svg);
    btn.appendChild(document.createTextNode(' Try Again'));
}
