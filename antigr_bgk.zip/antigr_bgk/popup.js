document.addEventListener('DOMContentLoaded', () => {
    const apiKeyInput = document.getElementById('apiKey');
    const saveBtn = document.getElementById('saveKeyBtn');
    const statusMsg = document.getElementById('statusMsg');
    const toggleVisibilityBtn = document.getElementById('toggleVisibility');

    // Load saved API key
    chrome.storage.local.get(['geminiApiKey'], (result) => {
        if (result.geminiApiKey) {
            apiKeyInput.value = result.geminiApiKey;
        }
    });

    // Toggle password visibility
    toggleVisibilityBtn.addEventListener('click', () => {
        const type = apiKeyInput.getAttribute('type') === 'password' ? 'text' : 'password';
        apiKeyInput.setAttribute('type', type);
    });

    // Save API key
    saveBtn.addEventListener('click', () => {
        const key = apiKeyInput.value.trim();
        if (!key) {
            showStatus('Please enter a valid API key.', 'error');
            return;
        }

        chrome.storage.local.set({ geminiApiKey: key }, () => {
            showStatus('API key saved successfully!', 'success');
        });
    });

    function showStatus(message, type) {
        statusMsg.textContent = message;
        statusMsg.className = `status ${type}`;
        
        setTimeout(() => {
            statusMsg.classList.add('hidden');
        }, 3000);
    }
});
