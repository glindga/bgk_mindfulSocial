import urllib.request

url = "https://raw.githubusercontent.com/google/material-design-icons/master/png/action/visibility/materialicons/48dp/2x/baseline_visibility_black_48dp.png"
sizes = [16, 48, 128]

# Create simple solid color icons since we don't have images
# In a real environment, we would use PIL. But we don't know if PIL is installed.
# Wait, let's just make a very simple black/grey box bitmap manually or fetch a placeholder icon.

# Actually, an extension icon can be easily created using a base64 encoded string or fetched from a URL.
# Let's download a generic eye/shield icon for the extension from a public URL to save them quickly.

import ssl
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

base_url = "https://via.placeholder.com/{size}/{color}/{text_color}.png?text=M"
for size in sizes:
    req = urllib.request.Request(
        base_url.format(size=size, color="0f172a", text_color="ffffff"),
        headers={'User-Agent': 'Mozilla/5.0'}
    )
    with urllib.request.urlopen(req, context=ctx) as response, open(f'icon{size}.png', 'wb') as out_file:
        data = response.read()
        out_file.write(data)
    print(f"Generated icon{size}.png")
